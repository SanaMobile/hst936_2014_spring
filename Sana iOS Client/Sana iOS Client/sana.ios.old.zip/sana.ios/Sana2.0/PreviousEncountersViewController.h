//
//  PreviousEncountersViewController.h
//  Sana
//
//  Created by Richard on 9/4/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PreviousEncountersViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>{

}

@end
