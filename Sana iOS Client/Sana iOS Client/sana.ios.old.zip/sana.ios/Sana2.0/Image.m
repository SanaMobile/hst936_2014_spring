//
//  Image.m
//  kidsAidMultimedia
//
//  Created by Richard Lu on 8/1/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "Image.h"
#import "Question.h"


@implementation Image
@dynamic name;
@dynamic contents;
@dynamic date;
@dynamic path;
@dynamic imageToQuestion;

@end
