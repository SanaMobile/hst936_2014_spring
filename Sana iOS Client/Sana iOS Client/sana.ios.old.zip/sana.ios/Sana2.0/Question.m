//
//  Question.m
//  kidsAidMultimedia
//
//  Created by Richard Lu on 8/1/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "Question.h"


@implementation Question
@dynamic title;
@dynamic date;
@dynamic questionToImage;


@end
