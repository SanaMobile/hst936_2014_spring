//
//  SanaConstants.m
//  Sana2.0
//
//  Created by Richard Lu on 7/30/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SanaConstants.h"

//add base URL constant
NSString * const ENCOUNTER_UPLOADER_QUEUE = @"edu.mit.sana.sds.queue.uploader";

