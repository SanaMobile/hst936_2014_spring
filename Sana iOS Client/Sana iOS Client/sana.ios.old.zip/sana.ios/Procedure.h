//
//  Form.h
//  Sana2.0
//
//  Created by Richard Lu on 7/30/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Procedure : NSObject {
    
    //a "Group" = a screen of content,
    //aka "Page" in the old Sana xml versions
    NSMutableArray *groupsArray;
}

@end
