//
//  Sana2_0Tests.m
//  Sana2.0Tests
//
//  Created by Richard Lu on 7/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Sana2_0Tests.h"

@implementation Sana2_0Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Sana2.0Tests");
}

@end
