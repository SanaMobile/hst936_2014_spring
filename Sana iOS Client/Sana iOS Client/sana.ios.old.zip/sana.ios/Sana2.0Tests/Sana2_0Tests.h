//
//  Sana2_0Tests.h
//  Sana2.0Tests
//
//  Created by Richard Lu on 7/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Sana2_0Tests : SenTestCase

@end
